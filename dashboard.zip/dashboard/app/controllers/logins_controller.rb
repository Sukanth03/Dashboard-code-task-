class LoginsController < ApplicationController

  # GET /logins
  def index
    
  end
  def create
    @name=params[:name]
    redirect_to :controller => '/homes', :action => 'index'
  end
end
