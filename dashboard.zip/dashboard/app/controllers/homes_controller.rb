class HomesController < ApplicationController

  # GET /homes
  def index
    raise @name.inspect
    @name1=@name
  end

 
end
